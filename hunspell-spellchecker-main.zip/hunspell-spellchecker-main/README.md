# hunspell-spellchecker
i want create a spellchecker file for my wordpress website tool
